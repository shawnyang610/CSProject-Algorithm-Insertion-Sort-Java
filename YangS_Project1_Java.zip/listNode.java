
public class listNode {
	public String data;
	public listNode next;
	
	listNode(){
		data = "dummy";
		next = null;
	}
	listNode(String x){
		data = x;
		next = null;
	}
}
